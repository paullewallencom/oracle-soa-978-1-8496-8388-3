package com.rubiconred.ckbk.creditcardsvc.pojo;

public class DebitCreditCardResponse {

	private String cardNumber;
	private String cardAuthCode;
	
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardAuthCode() {
		return cardAuthCode;
	}
	public void setCardAuthCode(String cardAuthCode) {
		this.cardAuthCode = cardAuthCode;
	}
	
}
