package soa.cookbook.model;

import java.io.Serializable;

public class Address implements Serializable {
  public Address() {
    super();
  }
  
  public Address(String addr, String city) {
    this.addr = addr;
    this.city = city;
  }
  
  private String addr;
  private String city;

  public void setAddr(String addr) {
    this.addr = addr;
  }

  public String getAddr() {
    return addr;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getCity() {
    return city;
  }
}
