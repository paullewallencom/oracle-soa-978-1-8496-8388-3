package soa.cookbook.model;

import javax.ejb.Local;

@Local
public interface EmployeeEJBLocal {
  public Employee getEmployeeByNumber(long number);
  public Employee addEmployee(String name, Address addr, String phone);
  public Employee[] getEmployees();
}
