package soa.cookbook;

import javax.ejb.Remote;

@Remote
public interface EXM_Mapping_EJB extends QuoteInterface {
}
