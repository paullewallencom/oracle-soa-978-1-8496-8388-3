package soa.cookbook;

import javax.ejb.Local;

@Local
public interface EXM_Mapping_EJBLocal extends QuoteInterface {
}
