package soa.cookbook;

public interface QuoteInterface {
  public QuoteResponse getQuotes(QuoteRequest request);
}
